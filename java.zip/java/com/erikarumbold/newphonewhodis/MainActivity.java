package com.erikarumbold.newphonewhodis;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private EditText name;
    private EditText email;
    private EditText phone;
    private Heroes heroes;
    private ImageView logo;
    private int counter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_layout);

        Button heroBtn = (Button) findViewById(R.id.button);
        name = (EditText) findViewById(R.id.name);
        email = (EditText) findViewById(R.id.email);
        phone = (EditText) findViewById(R.id.phone);
        logo = (ImageView) findViewById(R.id.logo);

        initializeListings();

        // creates Persons and stores them in Heroes
        Person batman = new Person("Batman", "bruce@wayne.com", "894.945.2121");
        Person flash = new Person("The Flash", "barry@STARlabs.org", "302.332.1949");
        Person aquaman = new Person("Aquaman", "fishboy41@atlantis.com", "592.816.5016");
        heroes = new Heroes(batman, flash, aquaman);

        heroBtn.setOnClickListener(toggleHero);
    }

    // switches hero info based on cycle each time button is clicked
    private final View.OnClickListener toggleHero = new View.OnClickListener(){
        public void onClick (View view){
            if (counter % 3 == 0){
                counter++;
                name.setText(heroes.getB().getName());
                email.setText(heroes.getB().getEmail());
                phone.setText(heroes.getB().getPhone());
                logo.setImageResource(R.drawable.batman);
            } else if (counter % 3 == 1){
                counter++;
                name.setText(heroes.getF().getName());
                email.setText(heroes.getF().getEmail());
                phone.setText(heroes.getF().getPhone());
                logo.setImageResource(R.drawable.flash);
            } else {
                counter++;
                name.setText(heroes.getA().getName());
                email.setText(heroes.getA().getEmail());
                phone.setText(heroes.getA().getPhone());
                logo.setImageResource(R.drawable.aquaman);
            }
        }
    };

    private void initializeListings(){
        counter = 0;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
