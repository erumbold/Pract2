package com.erikarumbold.newphonewhodis;

/**
 * Created by erikarumbold on 9/20/16.
 */
public class Person {
    private String name;
    private String email;
    private String phone;

    //creates a Person with their name, email, and phone number
    public Person(String n, String e, String p){
        this.name = n;
        this.email = e;
        this.phone = p;
    }

    public String getName(){return this.name;}
    public String getEmail(){return this.email;}
    public String getPhone(){return this.phone;}

}
