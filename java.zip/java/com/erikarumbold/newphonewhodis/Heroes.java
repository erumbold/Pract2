package com.erikarumbold.newphonewhodis;

/**
 * Created by erikarumbold on 9/20/16.
 */
public class Heroes {
    private Person[] p;

    //an array of Persons
    public Heroes(Person p1, Person p2, Person p3){
        this.p = new Person[3];

        this.p[0] = p1;
        this.p[1] = p2;
        this.p[2] = p3;
    }

    public Person getB(){return this.p[0];}
    public Person getF(){return this.p[1];}
    public Person getA(){return this.p[2];}
}
